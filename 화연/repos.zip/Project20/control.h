#pragma once
#include <iostream>
#include "entity.h"
using namespace std;

class SearchUI;
class PurchaseUI;
class PurchaseHistoryManageUI;
class EvaluateUI;

class Search {
private:
	SearchUI* searchUI;
	Clothes* clothes;
public:
	Search(Clothes* list);
	void search(string clothesName);
};

class Purchase {
private:
	PurchaseUI* purchaseUI;
	Clothes* clothes;
	ClothesDetail* purchaseClothes;
	User* user;
	System* system;
public:
	Purchase(Clothes* clothes, User* user, System* system);
	bool purchaseRequest();
	void makeHistory();
	void ifItemSold();
};

class PurchaseHistoryManage {
private:
	PurchaseHistoryManageUI* purchaseHistoryManageUI;
	User* user;
	System* system;
public:
	PurchaseHistoryManage(User* user, System* system);
	void viewHistory();
};

class Evaluate {
	private:
		EvaluateUI* evaluateUI;
		Clothes* clothes;
		System* system;
		User* user;
		ClothesDetail* selectedClothes;
public:
	Evaluate(Clothes* clothes, User* user, System* system);
	void searchHistory(string clothesName);
	void evaluateItem(int score);
};