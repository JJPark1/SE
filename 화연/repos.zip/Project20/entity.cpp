#include <string>
#include <cmath>
#include "entity.h"

string System::getUserID() { return UserID; }
void Evaluation::addScore(int s) { score += s; }
void Evaluation::increaseNum() { evaluatePeopleNum++; }
float Evaluation::getAverage() { return (float)score / evaluatePeopleNum; }
ClothesDetail* Clothes::getSellectedItem() {
	return sellectedItem;
}

string ClothesDetail::getName() {
	return name;
}

ClothesDetail::ClothesDetail(string name, string sellerID, string manufacturer, int price, int stock) :name(name),sellerID(sellerID),manufacturer(manufacturer),price(price),stock(stock),averageEvaluation(0){
	evaluation = new Evaluation;
}

void ClothesDetail::printItemDetail() {
	cout << sellerID << "/t" << name << "/t" << manufacturer << "/" << price << "/t" << averageEvaluation << "/t" << endl;
}
void ClothesDetail::evaluate(int score) { 
	evaluation->addScore(score);
	evaluation->increaseNum();
	float f = evaluation->getAverage();
	averageEvaluation = (int)round(f);
}
void ClothesDetail::decreaseStock() { stock -= 1; }
int ClothesDetail::getStock() { return stock; }
int ClothesDetail::getPrice() { return price; }
int ClothesDetail::getAverageEvaluation() { return averageEvaluation; }
string ClothesDetail::getSellerID() { return sellerID; }
string ClothesDetail::getManufacturer() { return manufacturer; }

void Clothes::addClothes(ClothesDetail* clothes){
	ClothesNode* NewNode = new ClothesNode;
	ClothesNode* LastNode;
	NewNode->clothesDetail = clothes;
	NewNode->link = NULL;
	if (head == NULL) {
		head = NewNode;
		return;
	}
	LastNode = head;
	while (LastNode->link != NULL) { LastNode = LastNode->link; }
	LastNode->link = NewNode;
}

void Clothes::deleteClothes(string clothesName) {
	ClothesNode* prevNode = head;
	ClothesNode* delNode;
	while (prevNode->link->clothesDetail->getName() != clothesName) {
		if (prevNode->link == NULL)return;
		prevNode = prevNode->link;
	}
	delNode = prevNode->link;
	prevNode->link = delNode->link;
	free(delNode);
}

bool Clothes::searchClothes(string clothesName) {
	ClothesNode* someNode = head;
	while (someNode->clothesDetail->getName() != clothesName) {
		if (someNode->link == NULL)return false;
		someNode = someNode->link;
	}
	sellectedItem = someNode->clothesDetail;
	return true;
}

void SoldClothesCollection::addClothes(ClothesDetail* clothes) {
	ClothesNode* NewNode = new ClothesNode;
	ClothesNode* LastNode;
	NewNode->clothesDetail = clothes;
	NewNode->link = NULL;
	if (head == NULL) {
		head = NewNode;
		return;
	}
	LastNode = head;
	while (LastNode->link != NULL) { LastNode = LastNode->link; }
	LastNode->link = NewNode;
}

void SoldClothesCollection::deleteClothes(string clothesName) {
	ClothesNode* prevNode = head;
	ClothesNode* delNode;
	while (prevNode->link->clothesDetail->getName() != clothesName) {
		prevNode = prevNode->link;
		if (prevNode->link == NULL)return;
	}
	delNode = prevNode->link;
	prevNode->link = delNode->link;
	free(delNode);
}

void ForSaleClothesCollection::addClothes(ClothesDetail* clothes) {
	ClothesNode* NewNode = new ClothesNode;
	ClothesNode* LastNode;
	NewNode->clothesDetail = clothes;
	NewNode->link = NULL;
	if (head == NULL) {
		head = NewNode;
		return;
	}
	LastNode = head;
	while (LastNode->link != NULL) { LastNode = LastNode->link; }
	LastNode->link = NewNode;
}

void ForSaleClothesCollection::deleteClothes(string clothesName) {
	ClothesNode* prevNode = head;
	ClothesNode* delNode;
	while (prevNode->link->clothesDetail->getName() != clothesName) {
		prevNode = prevNode->link;
		if (prevNode->link == NULL)return;
	}
	delNode = prevNode->link;
	prevNode->link = delNode->link;
	free(delNode);
}
string UserDetail::getID() { return ID; }

void PurchaseHistoryCollection::addClothes(ClothesDetail* clothes) {
	ClothesNode* NewNode = new ClothesNode;
	ClothesNode* LastNode;
	string clothesName = clothes->getName();
	NewNode->clothesDetail = clothes;
	NewNode->link = NULL;
	if (head == NULL) {
		head = NewNode;
		return;
	}
	LastNode = head;
	while (clothesName.compare(LastNode->link->clothesDetail->getName())>0) { LastNode = LastNode->link; }
	LastNode->link = NewNode;
}
ClothesNode* PurchaseHistoryCollection::getSelectedNode(){ return selectedNode; }
void PurchaseHistoryCollection::findFirst() { selectedNode = head; }
void PurchaseHistoryCollection::getNext() { selectedNode = selectedNode->link; }
void PurchaseHistoryCollection::getItemDetail() {
	if (selectedNode == NULL)return;
	ClothesDetail* clothes = selectedNode->clothesDetail;
	string name = clothes->getName(), sellerID = clothes->getSellerID(), manufacturer = clothes->getManufacturer();
	int price = clothes->getPrice(), averageEvaluation = clothes->getAverageEvaluation();
	cout << "/t" << sellerID << "/t" << name << "/t" << manufacturer << "/t" << price << "/t" << averageEvaluation << endl;
}
ClothesDetail* PurchaseHistoryCollection::findClothes(string clothesName) {
	ClothesNode* someNode = head;
	while (someNode->clothesDetail->getName() != clothesName) {
		if (someNode->link == NULL)return NULL;
		someNode = someNode->link;
	}
	return someNode->clothesDetail;
}

void PurchaseHistoryCollection::deleteClothes(string clothesName) {
	ClothesNode* prevNode = head;
	ClothesNode* delNode;
	while (prevNode->link->clothesDetail->getName() != clothesName) {
		prevNode = prevNode->link;
		if (prevNode->link == NULL)return;
	}
	delNode = prevNode->link;
	prevNode->link = delNode->link;
	free(delNode);
}

void User::addUser(UserDetail* userDetail) {
	UserNode* NewNode = new UserNode;
	UserNode* LastNode;
	NewNode->userDetail = userDetail;
	NewNode->link = NULL;
	if (head == NULL) {
		head = NewNode;
		return;
	}
	LastNode = head;
	while (LastNode->link != NULL) { LastNode = LastNode->link; }
	LastNode->link = NewNode;
}

void User::deleteUser(string ID) {
	UserNode* prevNode = head;
	UserNode* delNode;

	while (prevNode->link->userDetail->getID() != ID) {
		prevNode = prevNode->link;
		if (prevNode->link == NULL)return;
	}
	delNode = prevNode->link;
	prevNode->link = delNode->link;
	free(delNode);
}

bool User::searchUser(string ID) {
	UserNode* someNode = head;
	while (someNode->userDetail->getID() != ID) {
		if (someNode->link == NULL)return false;
		someNode = someNode->link;
	}
	selectedUser = someNode->userDetail;
	return true;
}

UserDetail* User::getSelectedUser() { return selectedUser; }
PurchaseHistoryCollection* UserDetail::getPurchaseHistoryCollection() { return purchaseHistoryCollection; }
void UserDetail::makePurchaseHistory(ClothesDetail* clothes) { purchaseHistoryCollection->addClothes(clothes); }
void UserDetail::removeForSaleList(string clothesName) { forSaleClothesCollection->deleteClothes(clothesName); }
void UserDetail::addSoldList(ClothesDetail* clothes) { soldClothesCollection->addClothes(clothes); }
void UserDetail::listPurchaseHistory() {
	purchaseHistoryCollection->findFirst();
	purchaseHistoryCollection->getItemDetail();
	purchaseHistoryCollection->getNext();
	while (purchaseHistoryCollection->getSelectedNode() != NULL) {
		purchaseHistoryCollection->getItemDetail();
		purchaseHistoryCollection->getNext();
	}
}