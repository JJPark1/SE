#pragma once
#include <iostream>
#include <fstream>
#include "control.h"
using namespace std;

class SearchUI {
private:
	Search* search;
public:
	SearchUI(Search* ss);
	void searchItemRequest();
};

class PurchaseUI {
private:
	Purchase* purchase;
public:
	PurchaseUI(Purchase* p);
	void buyItem();
};

class PurchaseHistoryManageUI {
private:
	PurchaseHistoryManage* purchaseHistoryManage;
public:
	PurchaseHistoryManageUI(PurchaseHistoryManage* p);
	void viewRequest();
};

class EvaluateUI {
private:
	Evaluate* evaluate;
public:
	EvaluateUI(Evaluate* p);
	void selectPurchasedItem();
	void evaluateRequest();
};