#include "boundary.h"
#include "control.h"
#include <fstream>
#include <string>

#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"

void doTask();

ifstream fin;
ofstream fout;

int main()
{
	fin.open(INPUT_FILE_NAME);
	fout.open(OUTPUT_FILE_NAME);
	doTask();
	return 0;
}

void doTask()
{
	int menu_level_1 = 0, menu_level_2 = 0; int is_program_exit = 0;
	while (!is_program_exit) {
		fin >> menu_level_1; fin >> menu_level_2;
		switch (menu_level_1)
		{
		case 1:
			{
				switch (menu_level_2)
				{
				case 1: {break; }//1.1
				case 2: {break; }//1.2
				default:break;
				}
				break;
			}
		case 2:
			{
				switch (menu_level_2)
				{
				case 1: {break; }//2.1
				case 2: {break; }//2.2
				default:break;
				}
				break;
			}
		case 3:
			{
				switch (menu_level_2)
				{
				case 1: {break; }//3.1
				case 2: {break; }//3.2
				case 3: {break; }//3.3
				default:break;
				}
				break;
			}
		case 4:
			{
				switch (menu_level_2)
				{
				case 1: {cout << "4.1" << "	��ǰ ���� �˻�" <<endl; break; }//4.1
				case 2: {cout << "4.2" << "	��ǰ ����" << endl; break; }//4.2
				case 3: {cout << "4.3" << "	��ǰ ���� ���� ��ȸ" << endl; break; }//4.3
				case 4: {cout << "4.4" << "	��ǰ ���Ÿ����� ��" << endl; break; }//4.4
				default:break;
				}
				break;
			}
		case 5:
			{
				switch (menu_level_2)
				{
				case 1: {break; }//5.1
				default:break;
				}
				break;
			}
		case 6:
			{
				switch (menu_level_2)
				{
				case 1: {is_program_exit = 1;
					break; }//6.1
				default:break;
				}
				break;
			}
		default: break;
		}
	}
	return;
}