#include <string>
#include "boundary.h"
SearchUI::SearchUI(Search* ss) :search(ss) {}

void SearchUI::searchItemRequest() {
	string clothesName;
	cin >> clothesName;
	search->search(clothesName);
}

PurchaseUI::PurchaseUI(Purchase* p) :purchase(p) {}

void PurchaseUI::buyItem() { 
	purchase->purchaseRequest();
	purchase->makeHistory();
	purchase->ifItemSold();
}

PurchaseHistoryManageUI::PurchaseHistoryManageUI(PurchaseHistoryManage* p) :purchaseHistoryManage(p) {}

void PurchaseHistoryManageUI::viewRequest() { purchaseHistoryManage->viewHistory(); }

EvaluateUI::EvaluateUI(Evaluate* p) : evaluate() {}
void EvaluateUI::selectPurchasedItem() {
	string clothesName;
	cin >> clothesName;
	evaluate->searchHistory(clothesName);
}
void EvaluateUI::evaluateRequest() {
	int score;
	cin >> score;
	evaluate->evaluateItem(score);
}