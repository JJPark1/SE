#include <string>
#include "control.h"
#include "boundary.h"

Search::Search(Clothes* list) :clothes(list) { searchUI = new SearchUI(this); }

void Search::search(string clothesName) {
	ClothesDetail* searchitem;
	if (clothes->searchClothes(clothesName)) {
		searchitem = clothes->getSellectedItem();
		searchitem->printItemDetail();
	}
}

Purchase::Purchase(Clothes* clothes, User* user, System* system) :clothes(clothes), user(user), system(system) { purchaseUI = new PurchaseUI(this); purchaseClothes = NULL; }

bool Purchase::purchaseRequest() {
	purchaseClothes = clothes->getSellectedItem();
	if (purchaseClothes->getStock() > 0) {
		purchaseClothes->decreaseStock();
		return true;
	}
	else
		return false;
}

void Purchase::makeHistory() {
	string userID = system->getUserID();
	if (user->searchUser(userID)) {
		user->getSelectedUser()->makePurchaseHistory(purchaseClothes);
	}
}

void Purchase::ifItemSold() {
	if (purchaseClothes->getStock() <= 0) {
		UserDetail* userDetail;
		string sellerID;
		sellerID = purchaseClothes->getSellerID();
		if (user->searchUser(sellerID)) {
			userDetail = user->getSelectedUser();
			userDetail->addSoldList(purchaseClothes);
			userDetail->removeForSaleList(purchaseClothes->getName());
		}
	}
}

PurchaseHistoryManage::PurchaseHistoryManage(User* user, System* system) :user(user), system(system) { purchaseHistoryManageUI = new PurchaseHistoryManageUI(this); }
void PurchaseHistoryManage::viewHistory() {
	string userID = system->getUserID();
	if (user->searchUser(userID)) {
		user->getSelectedUser()->listPurchaseHistory();
	}
}

Evaluate::Evaluate(Clothes* clothes, User* user, System* system) :clothes(clothes), user(user), system(system) { evaluateUI = new EvaluateUI(this); selectedClothes = NULL; }
void Evaluate::searchHistory(string clothesName) {
	string userID = system->getUserID();
	if (user->searchUser(userID)) {
		selectedClothes = user->getSelectedUser()->getPurchaseHistoryCollection()->findClothes(clothesName);
	}	
}
void Evaluate::evaluateItem(int score) { selectedClothes->evaluate(score); }