#pragma once
#include <iostream>
using namespace std;

class System {
	string UserID;
public:
	string getUserID();
};
class Evaluation{
	int score = 0, evaluatePeopleNum = 0;
public:
	void addScore(int s);
	void increaseNum();
	float getAverage();
};

class ClothesDetail {
	string name, sellerID, manufacturer;
	int price, stock, averageEvaluation;
	Evaluation* evaluation;
public:
	ClothesDetail(string name, string sellerID, string manufacturer, int price, int stock);
	string getName();
	void printItemDetail();
	void decreaseStock();
	void evaluate(int score);
	int getStock();
	int getPrice();
	int getAverageEvaluation();
	string getSellerID();
	string getManufacturer();
};

struct ClothesNode {
	ClothesDetail* clothesDetail;
	struct ClothesNode* link;
};

class Clothes {
	ClothesNode* head;
	ClothesDetail* sellectedItem;
public:
	void addClothes(ClothesDetail* clothes);
	void deleteClothes(string clothesName);
	bool searchClothes(string clothesName);
	ClothesDetail* getSellectedItem();
};

class ForSaleClothesCollection {
	ClothesNode* head;
public:
	void addClothes(ClothesDetail* clothes);
	void deleteClothes(string clothesName);
};

class SoldClothesCollection {
	ClothesNode* head;
public:
	void addClothes(ClothesDetail* clothes);
	void deleteClothes(string clothesName);
};

class PurchaseHistoryCollection {
	ClothesNode* head;
	ClothesNode* selectedNode;
public:
	void addClothes(ClothesDetail* clothes);
	void deleteClothes(string clothesName);
	void findFirst();
	void getNext();
	void getItemDetail();
	ClothesDetail* findClothes(string clothesName);
	ClothesNode* getSelectedNode();
};

class UserDetail {
	string ID;
	ForSaleClothesCollection* forSaleClothesCollection;
	SoldClothesCollection* soldClothesCollection;
	PurchaseHistoryCollection* purchaseHistoryCollection;
public:
	string getID();
	void makePurchaseHistory(ClothesDetail* clothes);
	void removeForSaleList(string clothesName);
	void addSoldList(ClothesDetail* clothes);
	void listPurchaseHistory();
	PurchaseHistoryCollection* getPurchaseHistoryCollection();
};

struct UserNode {
	UserDetail* userDetail;
	struct UserNode* link;
};

class User {
	UserNode* head;
	UserDetail* selectedUser;
public:
	void addUser(UserDetail* userDetail);
	void deleteUser(string ID);
	bool searchUser(string ID);
	UserDetail* getSelectedUser();
};
